# FaceLock – Face ID-style lock for Android

Kotlin + Jetpack Compose starter. Front camera → ML Kit face detection → blink liveness
check → MobileFaceNet embedding → match → Face ID-style animation + haptics.

## Setup (3 steps)
1. Open this folder in **Android Studio** (Koala or newer) and let Gradle sync.
2. **Add the model:** download a MobileFaceNet TFLite model (input 112x112x3, output 192 floats)
   and save it as `app/src/main/assets/mobilefacenet.tflite`.
   (Search "MobileFaceNet tflite" – several open-source repos provide one. Check its licence.)
3. Run on a **real phone** (emulator cameras are unreliable for this).

First launch asks you to enroll your face (blink once). After that the app opens locked.

## Files
| File | Job |
|------|-----|
| `FaceIdAnimation.kt` | The animated brackets, scan line, green checkmark, shake on fail |
| `FaceAnalyzer.kt` | Per-frame detection, blink liveness, matching. `THRESHOLD` is tunable |
| `FaceEmbedder.kt` | TFLite model → face embedding |
| `FaceStore.kt` | Saves the embedding encrypted with Android Keystore |
| `FaceLockScreen.kt` | Camera preview + animation + haptics screen |
| `MainActivity.kt` | Permission, enroll / lock / home flow. Replace HOME with your app |

## Tuning for speed and accuracy
- Lower `THRESHOLD` (0.65) = more forgiving, higher = stricter. Test on your own devices.
- Speed comes from `PERFORMANCE_MODE_FAST`, `STRATEGY_KEEP_ONLY_LATEST` and 4 TFLite threads.
- For more speed, use a quantized model or the GPU delegate (`org.tensorflow:tensorflow-lite-gpu`).

## Security note (important)
This is a **2D camera** system. A blink check stops simple photos, but it is not as strong as
iPhone Face ID (3D depth) and can be beaten by a video or mask. Use it for app-lock/convenience.
For payments, banking or sensitive data, add `androidx.biometric` `BiometricPrompt` (Class 3)
as the real security gate.

## Build the APK online (no computer needed)
1. Create a free GitHub account and a new repository named FaceLock.
2. Upload every file and folder from this project (the GitHub website's "Add file > Upload files" works on a phone browser; keep the folder structure, including the hidden `.github` folder).
3. Upload `mobilefacenet.tflite` into `app/src/main/assets/`.
4. Open the **Actions** tab > **Build APK** > **Run workflow**.
5. When it finishes (about 5 minutes), open the run and download **FaceLock-debug-apk**, unzip it, and install `app-debug.apk` on your phone (allow "Install unknown apps").
