package com.example.facelock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Runs in the background, checks every 250 ms which app is open, and when it is one of the
 * locked apps shows [LockActivity] (face unlock) on top of it.
 */
class LockService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastForeground: String? = null

    private val tick = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) { }
            handler.postDelayed(this, 250)
        }
    }

    // Screen turned off -> everything must be unlocked again with the face
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            AppLockState.validUntil.clear()
            AppLockState.pending = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(screenOff) } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun check() {
        val now = System.currentTimeMillis()
        val seen = foregroundPackage()

        if (seen != null && seen != lastForeground) {
            // Leaving an unlocked app starts a short grace period (so quick app switching is easy)
            lastForeground?.let { previous ->
                if (AppLockState.validUntil.containsKey(previous)) {
                    AppLockState.validUntil[previous] = now + AppPrefs.graceMs(this)
                }
            }
            lastForeground = seen
            AppLockState.pending = null
        }

        val current = lastForeground ?: return
        if (current in AppPrefs.lockedPackages(this)) {
            val validUntil = AppLockState.validUntil[current] ?: 0L
            if (validUntil > now) {
                AppLockState.validUntil[current] = Long.MAX_VALUE
            } else if (AppLockState.pending != current) {
                AppLockState.pending = current
                launchLock(current)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 10_000, now) ?: return null
        val event = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                val isOurLockScreen =
                    event.packageName == packageName && event.className == LockActivity::class.java.name
                if (!isOurLockScreen) last = event.packageName
            }
        }
        return last
    }

    private fun launchLock(pkg: String) {
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }

        val intent = Intent(this, LockActivity::class.java)
            .putExtra(LockActivity.EXTRA_PKG, pkg)
            .putExtra(LockActivity.EXTRA_LABEL, label)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(intent)
    }

    private fun startAsForeground() {
        val channel = NotificationChannel(CHANNEL, "FaceLock protection", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("FaceLock is protecting your apps")
            .setContentText("Tap to choose which apps are locked")
            .setContentIntent(open)
            .setOngoing(true)
            .build()

        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, notification, type)
    }

    private companion object {
        const val CHANNEL = "facelock_protection"
    }
}
