package com.example.facelock

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Turns a cropped face bitmap into a 192-number "embedding" using MobileFaceNet.
 * Put the model at app/src/main/assets/mobilefacenet.tflite (input 112x112x3, any embedding size).
 */
class FaceEmbedder(context: Context) {

    private val interpreter: Interpreter
    private val embeddingSize: Int

    init {
        val fd = context.assets.openFd(MODEL)
        val buffer = fd.createInputStream().channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(buffer, Interpreter.Options().setNumThreads(4))
        // Works with any MobileFaceNet variant (128, 192 or 512 numbers)
        embeddingSize = interpreter.getOutputTensor(0).shape().last()
    }

    fun embed(face: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(face, SIZE, SIZE, true)
        val input = ByteBuffer.allocateDirect(4 * SIZE * SIZE * 3).order(ByteOrder.nativeOrder())
        val pixels = IntArray(SIZE * SIZE)
        scaled.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
        for (p in pixels) {
            input.putFloat((((p shr 16) and 0xFF) - 127.5f) / 128f)
            input.putFloat((((p shr 8) and 0xFF) - 127.5f) / 128f)
            input.putFloat(((p and 0xFF) - 127.5f) / 128f)
        }
        val output = Array(1) { FloatArray(embeddingSize) }
        interpreter.run(input, output)
        return normalize(output[0])
    }

    private fun normalize(v: FloatArray): FloatArray {
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat().coerceAtLeast(1e-9f)
        return FloatArray(v.size) { v[it] / norm }
    }

    companion object {
        private const val MODEL = "mobilefacenet.tflite"
        private const val SIZE = 112

        /** Cosine similarity of two normalized embeddings (1.0 = identical). */
        fun similarity(a: FloatArray, b: FloatArray): Float {
            var dot = 0f
            for (i in a.indices) dot += a[i] * b[i]
            return dot
        }
    }
}
