package com.example.facelock

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the enrolled face embedding encrypted with a key held in Android Keystore.
 * Only the numeric embedding is saved, never a photo.
 */
class FaceStore(context: Context) {

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "face_store",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun isEnrolled() = prefs.contains(KEY)

    fun save(embedding: FloatArray) {
        prefs.edit().putString(KEY, embedding.joinToString(",")).apply()
    }

    fun load(): FloatArray? =
        prefs.getString(KEY, null)?.split(",")?.map { it.toFloat() }?.toFloatArray()

    fun clear() = prefs.edit().remove(KEY).apply()

    private companion object { const val KEY = "embedding" }
}
