package com.example.facelock

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/** Which apps are locked, and whether protection is switched on. */
object AppPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("applock", Context.MODE_PRIVATE)

    fun lockedPackages(c: Context): Set<String> =
        prefs(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val set = HashSet(lockedPackages(c))
        if (on) set.add(pkg) else set.remove(pkg)
        prefs(c).edit().putStringSet("locked", set).apply()
    }

    /** How long an unlocked app stays unlocked after you leave it. -1 = until the screen turns off. */
    fun graceSeconds(c: Context): Int = prefs(c).getInt("grace", 10)

    fun setGraceSeconds(c: Context, seconds: Int) {
        prefs(c).edit().putInt("grace", seconds).apply()
    }

    fun graceMs(c: Context): Long {
        val s = graceSeconds(c)
        return if (s < 0) Long.MAX_VALUE / 4 else s * 1000L
    }

    fun protectionOn(c: Context) = prefs(c).getBoolean("on", false)

    fun setProtection(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("on", on).apply()
    }
}

/** Shared in-memory state between the watcher service and the lock screen. */
object AppLockState {
    /** package -> time until which it counts as unlocked (Long.MAX_VALUE = while it stays open) */
    val validUntil = ConcurrentHashMap<String, Long>()

    /** The app we are currently showing the lock screen for (prevents opening it twice). */
    @Volatile var pending: String? = null
}
