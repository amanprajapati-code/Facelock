package com.example.facelock

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppItem(val pkg: String, val label: String, val icon: ImageBitmap)

/** Main screen: finish setup, switch protection on, choose which apps to lock. */
@Composable
fun HomeScreen(onReEnroll: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var refresh by remember { mutableIntStateOf(0) }

    // Re-check permissions every time the user comes back from Settings
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    val cameraLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val notificationLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    val hasCamera = remember(refresh) { Perms.camera(context) }
    val hasUsage = remember(refresh) { Perms.usage(context) }
    val hasOverlay = remember(refresh) { Perms.overlay(context) }
    val hasNotifications = remember(refresh) { Perms.notifications(context) }
    val ready = hasCamera && hasUsage && hasOverlay

    var protection by remember { mutableStateOf(AppPrefs.protectionOn(context)) }
    var locked by remember { mutableStateOf(AppPrefs.lockedPackages(context)) }
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var query by remember { mutableStateOf("") }
    var grace by remember { mutableIntStateOf(AppPrefs.graceSeconds(context)) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(context) } }

    // Keep the watcher service running while protection is on
    LaunchedEffect(refresh, protection, ready) {
        if (protection && ready) {
            ContextCompat.startForegroundService(context, Intent(context, LockService::class.java))
        }
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            Text("FaceLock", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Lock any app with your face", color = Color.Gray)
            Spacer(Modifier.height(16.dp))
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("1. Allow these", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    PermRow("Camera", hasCamera) { cameraLauncher.launch(Manifest.permission.CAMERA) }
                    PermRow("Usage access (sees which app is open)", hasUsage) { Perms.openUsage(context) }
                    PermRow("Display over other apps (shows the lock)", hasOverlay) { Perms.openOverlay(context) }
                    if (Build.VERSION.SDK_INT >= 33) {
                        PermRow("Notifications (optional)", hasNotifications) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(onClick = { Perms.openBattery(context) }) {
                        Text("Keep running in background (recommended)")
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("2. Turn on protection", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Text(
                            when {
                                !ready -> "Finish step 1 first"
                                protection -> "ON: locked apps need your face"
                                else -> "OFF"
                            },
                            color = Color.Gray
                        )
                    }
                    Switch(
                        checked = protection && ready,
                        enabled = ready,
                        onCheckedChange = { on ->
                            protection = on
                            AppPrefs.setProtection(context, on)
                            if (!on) context.stopService(Intent(context, LockService::class.java))
                        }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Remember unlock for", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text(
                        "After you unlock an app, it stays unlocked this long after you leave it. " +
                            "Turning the screen off always locks everything again.",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    val options = listOf(
                        "10 sec" to 10, "1 min" to 60, "5 min" to 300,
                        "15 min" to 900, "Until screen off" to -1
                    )
                    for (row in options.chunked(3)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for ((label, seconds) in row) {
                                val pick = {
                                    grace = seconds
                                    AppPrefs.setGraceSeconds(context, seconds)
                                }
                                if (grace == seconds) {
                                    Button(onClick = pick, modifier = Modifier.weight(1f)) { Text(label, fontSize = 12.sp) }
                                } else {
                                    OutlinedButton(onClick = pick, modifier = Modifier.weight(1f)) { Text(label, fontSize = 12.sp) }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        item {
            Text("3. Choose apps to lock (${locked.size} locked)", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }

        val list = apps
        if (list == null) {
            item { Text("Loading apps…", color = Color.Gray) }
        } else {
            val shown = list.filter { it.label.contains(query, ignoreCase = true) }
            items(shown, key = { it.pkg }) { app ->
                AppRow(app, app.pkg in locked) { on ->
                    AppPrefs.setLocked(context, app.pkg, on)
                    locked = AppPrefs.lockedPackages(context)
                }
            }
        }

        item {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onReEnroll) { Text("Re-enroll my face") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PermRow(title: String, ok: Boolean, onAllow: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            if (ok) "✓" else "•",
            color = if (ok) Color(0xFF2E7D32) else Color(0xFFB00020),
            fontSize = 20.sp,
            modifier = Modifier.width(28.dp)
        )
        Text(title, Modifier.weight(1f))
        if (!ok) Button(onClick = onAllow) { Text("Allow") }
    }
}

@Composable
private fun AppRow(app: AppItem, locked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(44.dp))
        Spacer(Modifier.width(14.dp))
        Text(app.label, Modifier.weight(1f), fontSize = 16.sp)
        Switch(checked = locked, onCheckedChange = onToggle)
    }
}

private fun loadApps(c: Context): List<AppItem> {
    val pm = c.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != c.packageName }
        .map { info ->
            AppItem(
                pkg = info.activityInfo.packageName,
                label = info.loadLabel(pm).toString(),
                icon = info.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}
