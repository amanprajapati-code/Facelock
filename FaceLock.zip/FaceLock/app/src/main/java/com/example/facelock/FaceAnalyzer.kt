package com.example.facelock

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

enum class ScanState { SEARCHING, SCANNING, SUCCESS, FAIL }

/**
 * Per-frame pipeline: detect face -> require blink (liveness) -> embed -> compare.
 * [onState] and [onResult] are called on the analyzer thread; post to main if needed.
 */
class FaceAnalyzer(
    private val embedder: FaceEmbedder,
    private val enrolled: FloatArray?,          // null = enrollment mode
    private val onState: (ScanState) -> Unit,
    private val onEnrolled: (FloatArray) -> Unit,
    private val onUnlocked: () -> Unit,
) : ImageAnalysis.Analyzer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL) // eye-open probability
            .setMinFaceSize(0.35f)
            .build()
    )

    @Volatile private var done = false
    private var sawEyesOpen = false
    private var sawBlink = false
    private var failedFrames = 0

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    override fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (done || media == null) { proxy.close(); return }

        val rotation = proxy.imageInfo.rotationDegrees
        val input = InputImage.fromMediaImage(media, rotation)

        detector.process(input)
            .addOnSuccessListener { faces ->
                val face = faces.maxByOrNull { it.boundingBox.width() }
                if (face == null) {
                    onState(ScanState.SEARCHING)
                } else {
                    handleFace(face, proxy, rotation)
                }
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun handleFace(face: Face, proxy: ImageProxy, rotation: Int) {
        onState(ScanState.SCANNING)

        // Must look roughly at the camera
        if (kotlin.math.abs(face.headEulerAngleY) > 20 || kotlin.math.abs(face.headEulerAngleX) > 20) return

        // Liveness: eyes open, then closed, then open again (a blink). A still photo can't do this.
        val l = face.leftEyeOpenProbability ?: return
        val r = face.rightEyeOpenProbability ?: return
        val open = l > 0.7f && r > 0.7f
        val closed = l < 0.25f && r < 0.25f
        if (open && !sawEyesOpen) sawEyesOpen = true
        if (closed && sawEyesOpen) sawBlink = true
        if (!(sawBlink && open)) return

        val bitmap = proxy.toBitmapRotated(rotation) ?: return
        val crop = bitmap.cropSafe(face.boundingBox) ?: return
        val embedding = embedder.embed(crop)

        if (enrolled == null) {
            done = true
            onEnrolled(embedding)
            onState(ScanState.SUCCESS)
            return
        }

        val score = FaceEmbedder.similarity(embedding, enrolled)
        if (score >= THRESHOLD) {
            done = true
            onState(ScanState.SUCCESS)
            onUnlocked()
        } else {
            sawEyesOpen = false; sawBlink = false      // ask for a fresh blink
            if (++failedFrames >= 3) { failedFrames = 0; onState(ScanState.FAIL) }
        }
    }

    private fun ImageProxy.toBitmapRotated(rotation: Int): Bitmap? = try {
        val bmp = toBitmap()
        val m = Matrix().apply { postRotate(rotation.toFloat()); postScale(-1f, 1f) }
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    } catch (e: Exception) { null }

    private fun Bitmap.cropSafe(r: Rect): Bitmap? {
        val box = Rect(r)
        val x = box.left.coerceIn(0, width - 1)
        val y = box.top.coerceIn(0, height - 1)
        val w = box.width().coerceAtMost(width - x)
        val h = box.height().coerceAtMost(height - y)
        return if (w > 20 && h > 20) Bitmap.createBitmap(this, x, y, w, h) else null
    }

    companion object {
        /** Tune on real devices: higher = stricter. ~0.6-0.7 is a typical start for MobileFaceNet. */
        const val THRESHOLD = 0.65f
    }
}
