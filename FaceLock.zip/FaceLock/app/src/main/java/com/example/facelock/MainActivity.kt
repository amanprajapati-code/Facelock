package com.example.facelock

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private enum class Screen { HOME, ENROLL, LOCK }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = FaceStore(this)

        setContent {
            var hasCamera by remember {
                mutableStateOf(
                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                )
            }
            val permissionLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCamera = it }

            LaunchedEffect(Unit) { if (!hasCamera) permissionLauncher.launch(Manifest.permission.CAMERA) }

            // First launch: enroll. After that: start locked.
            var screen by remember { mutableStateOf(if (store.isEnrolled()) Screen.LOCK else Screen.ENROLL) }

            if (!hasCamera) {
                Centered { Text("Camera permission is needed for Face ID", color = Color.White) }
                return@setContent
            }

            when (screen) {
                Screen.ENROLL -> FaceLockScreen(
                    enrollMode = true,
                    onEnrolled = { screen = Screen.HOME },
                    onUnlocked = {}
                )
                Screen.LOCK -> FaceLockScreen(
                    enrollMode = false,
                    onEnrolled = {},
                    onUnlocked = { screen = Screen.HOME }
                )
                Screen.HOME -> Centered {
                    // ---- Replace this with your real app ----
                    Text("Welcome — you're unlocked", color = Color.White, fontSize = 22.sp)
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { screen = Screen.LOCK }) { Text("Lock") }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { store.clear(); screen = Screen.ENROLL }) { Text("Re-enroll face") }
                }
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color.Black),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}
