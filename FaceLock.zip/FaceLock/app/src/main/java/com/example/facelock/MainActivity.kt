package com.example.facelock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private enum class Screen { ENROLL, LOCK, HOME }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = FaceStore(this)

        setContent {
            var hasCamera by remember {
                mutableStateOf(
                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                )
            }
            val permissionLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCamera = it }

            LaunchedEffect(Unit) { if (!hasCamera) permissionLauncher.launch(Manifest.permission.CAMERA) }

            // First launch: enroll your face. After that the FaceLock app itself is locked too.
            var screen by remember { mutableStateOf(if (store.isEnrolled()) Screen.LOCK else Screen.ENROLL) }

            if (!hasCamera) {
                Centered { Text("Camera permission is needed for Face ID", color = Color.White) }
                return@setContent
            }

            when (screen) {
                Screen.ENROLL -> FaceLockScreen(
                    enrollMode = true,
                    onEnrolled = { screen = Screen.HOME },
                    onUnlocked = {}
                )
                Screen.LOCK -> FaceLockScreen(
                    enrollMode = false,
                    onEnrolled = {},
                    onUnlocked = { screen = Screen.HOME }
                )
                Screen.HOME -> HomeScreen(
                    onReEnroll = {
                        store.clear()
                        AppPrefs.setProtection(this@MainActivity, false)
                        stopService(Intent(this@MainActivity, LockService::class.java))
                        screen = Screen.ENROLL
                    }
                )
            }
        }
    }
}

@Composable
private fun Centered(bg: Color = Color.Black, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(bg),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}
