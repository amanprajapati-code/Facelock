package com.example.facelock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Restarts protection after the phone reboots (if it was switched on). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && AppPrefs.protectionOn(context)) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, LockService::class.java))
            } catch (_: Exception) { }
        }
    }
}
