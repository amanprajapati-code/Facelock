package com.example.facelock

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * "Island" style face unlock badge (inspired by phone camera-cutout animations):
 *
 *  1. A black rounded badge drops down from the top of the screen with a spring.
 *  2. SEARCHING: white face icon gently breathes.
 *  3. SCANNING : face icon dims and a white ring spins around it.
 *  4. FAIL     : icon turns red and the badge shakes.
 *  5. SUCCESS  : green ring draws, green check draws, then the badge shrinks back
 *                up into the top of the screen and fades away.
 *
 * Total SUCCESS time is about 1.45 seconds (ring 350 + check 300 + hold 450 + retract 350 ms).
 */
@Composable
fun FaceIdAnimation(state: ScanState, modifier: Modifier = Modifier, size: Dp = 76.dp) {
    val appear = remember { Animatable(0f) }
    val retract = remember { Animatable(0f) }
    val shake = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val check = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        appear.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 320f))
    }

    LaunchedEffect(state) {
        when (state) {
            ScanState.FAIL -> {
                repeat(3) {
                    shake.animateTo(1f, tween(55))
                    shake.animateTo(-1f, tween(55))
                }
                shake.animateTo(0f, tween(55))
            }
            ScanState.SUCCESS -> {
                ring.animateTo(1f, tween(350))
                check.animateTo(1f, tween(300))
                kotlinx.coroutines.delay(450)
                retract.animateTo(1f, tween(350, easing = FastOutSlowInEasing))
            }
            else -> {}
        }
    }

    val infinite = rememberInfiniteTransition(label = "infinite")
    val spin by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "spin"
    )
    val breathe by infinite.animateFloat(
        initialValue = 0.65f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "breathe"
    )

    val green = Color(0xFF30D158)
    val glyphColor = if (state == ScanState.FAIL) Color(0xFFFF453A) else Color.White
    val glyphAlpha = when (state) {
        ScanState.SEARCHING -> breathe
        ScanState.SCANNING -> 0.35f
        ScanState.FAIL -> 1f
        ScanState.SUCCESS -> 0f
    }

    Canvas(
        modifier
            .size(size)
            .graphicsLayer {
                val a = appear.value
                val r = retract.value
                transformOrigin = TransformOrigin(0.5f, 0f)
                val sc = (0.25f + 0.75f * a) * (1f - 0.8f * r)
                scaleX = sc
                scaleY = sc
                translationY = -(1f - a) * 30.dp.toPx()
                translationX = shake.value * 10.dp.toPx()
                alpha = a.coerceIn(0f, 1f) * (1f - r)
            }
    ) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        val stroke = s * 0.04f

        // Black badge
        drawRoundRect(
            color = Color.Black,
            size = Size(s, s),
            cornerRadius = CornerRadius(s * 0.32f, s * 0.32f)
        )

        // Face icon: circle, two eyes, smile
        if (glyphAlpha > 0f) {
            val col = glyphColor.copy(alpha = glyphAlpha)
            drawCircle(color = col, radius = s * 0.22f, center = c, style = Stroke(width = stroke))
            drawCircle(color = col, radius = s * 0.026f, center = Offset(c.x - s * 0.08f, c.y - s * 0.05f))
            drawCircle(color = col, radius = s * 0.026f, center = Offset(c.x + s * 0.08f, c.y - s * 0.05f))
            drawArc(
                color = col,
                startAngle = 25f,
                sweepAngle = 130f,
                useCenter = false,
                topLeft = Offset(c.x - s * 0.11f, c.y - s * 0.09f),
                size = Size(s * 0.22f, s * 0.2f),
                style = Stroke(width = stroke * 0.8f, cap = StrokeCap.Round)
            )
        }

        // Spinning scan ring
        if (state == ScanState.SCANNING) {
            drawArc(
                color = Color.White,
                startAngle = spin,
                sweepAngle = 110f,
                useCenter = false,
                topLeft = Offset(c.x - s * 0.3f, c.y - s * 0.3f),
                size = Size(s * 0.6f, s * 0.6f),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }

        // Green success ring + check mark
        if (ring.value > 0f) {
            drawArc(
                color = green,
                startAngle = -90f,
                sweepAngle = 360f * ring.value,
                useCenter = false,
                topLeft = Offset(c.x - s * 0.27f, c.y - s * 0.27f),
                size = Size(s * 0.54f, s * 0.54f),
                style = Stroke(width = stroke * 1.1f, cap = StrokeCap.Round)
            )
            val full = Path().apply {
                moveTo(s * 0.37f, s * 0.51f)
                lineTo(s * 0.46f, s * 0.60f)
                lineTo(s * 0.64f, s * 0.41f)
            }
            val part = Path()
            val measure = PathMeasure()
            measure.setPath(full, false)
            measure.getSegment(0f, measure.length * check.value, part, true)
            drawPath(part, color = green, style = Stroke(width = stroke * 1.2f, cap = StrokeCap.Round))
        }
    }
}
