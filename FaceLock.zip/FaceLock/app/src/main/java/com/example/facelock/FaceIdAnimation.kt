package com.example.facelock

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Face ID-style indicator:
 *  SEARCHING - four white corner brackets, gently pulsing
 *  SCANNING  - brackets + rotating arc + moving scan line
 *  SUCCESS   - ring closes, green circle, checkmark draws itself
 *  FAIL      - red brackets shake side to side
 */
@Composable
fun FaceIdAnimation(state: ScanState, modifier: Modifier = Modifier, size: Dp = 240.dp) {
    val infinite = rememberInfiniteTransition(label = "loop")
    val pulse by infinite.animateFloat(
        0.85f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse"
    )
    val spin by infinite.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "spin"
    )
    val scan by infinite.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scan"
    )

    val success by animateFloatAsState(
        if (state == ScanState.SUCCESS) 1f else 0f, tween(450), label = "success"
    )
    val check by animateFloatAsState(
        if (state == ScanState.SUCCESS) 1f else 0f, tween(500, delayMillis = 250), label = "check"
    )

    val shake = remember { Animatable(0f) }
    LaunchedEffect(state) {
        if (state == ScanState.FAIL) {
            repeat(3) { shake.animateTo(18f, tween(55)); shake.animateTo(-18f, tween(55)) }
            shake.animateTo(0f, tween(55))
        }
    }

    val bracketColor = when (state) {
        ScanState.FAIL -> Color(0xFFFF453A)
        ScanState.SUCCESS -> Color(0xFF30D158)
        else -> Color.White
    }

    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        translate(left = shake.value) {
            if (success < 1f) {
                val a = (1f - success)
                drawBrackets(s, bracketColor.copy(alpha = a), if (state == ScanState.SEARCHING) pulse else 1f)

                if (state == ScanState.SCANNING) {
                    val inset = s * 0.18f
                    drawArc(
                        color = Color(0xFF64D2FF), startAngle = spin, sweepAngle = 90f, useCenter = false,
                        topLeft = Offset(inset, inset), size = Size(s - inset * 2, s - inset * 2),
                        style = Stroke(width = s * 0.015f, cap = StrokeCap.Round)
                    )
                    val y = s * 0.2f + (s * 0.6f) * scan
                    drawLine(
                        Color(0xFF64D2FF).copy(alpha = 0.8f),
                        Offset(s * 0.2f, y), Offset(s * 0.8f, y), strokeWidth = s * 0.008f, cap = StrokeCap.Round
                    )
                }
            }

            if (success > 0f) {
                val c = Offset(s / 2, s / 2)
                drawCircle(Color(0xFF30D158), radius = s * 0.32f * success, center = c)
                val p = Path().apply {
                    moveTo(s * 0.38f, s * 0.52f)
                    lineTo(s * 0.47f, s * 0.61f)
                    lineTo(s * 0.64f, s * 0.42f)
                }
                val seg = Path()
                val pm = PathMeasure().apply { setPath(p, false) }
                pm.getSegment(0f, pm.length * check, seg, true)
                drawPath(seg, Color.White, style = Stroke(width = s * 0.045f, cap = StrokeCap.Round))
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBrackets(s: Float, color: Color, scale: Float) {
    val len = s * 0.18f
    val stroke = Stroke(width = s * 0.025f, cap = StrokeCap.Round)
    val m = s * (0.5f - 0.36f * scale)      // margin shrinks/grows with pulse
    val e = s - m
    fun corner(x: Float, y: Float, dx: Float, dy: Float) {
        val p = Path().apply { moveTo(x, y + dy * len); lineTo(x, y); lineTo(x + dx * len, y) }
        drawPath(p, color, style = stroke)
    }
    corner(m, m, 1f, 1f); corner(e, m, -1f, 1f); corner(m, e, 1f, -1f); corner(e, e, -1f, -1f)
}
