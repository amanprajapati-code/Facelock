package com.example.facelock

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Lock screen with the island-style face unlock badge at the top.
 * @param enrollMode true = save a new face (shows a small camera preview),
 *                   false = verify against the saved face (no preview, like a real phone).
 */
@Composable
fun FaceLockScreen(
    enrollMode: Boolean,
    onEnrolled: () -> Unit,
    onUnlocked: () -> Unit,
    title: String? = null,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val store = remember { FaceStore(context) }
    val embedder = remember { FaceEmbedder(context) }
    var state by remember { mutableStateOf(ScanState.SEARCHING) }
    var whiteOut by remember { mutableStateOf(false) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    val analyzer = remember {
        FaceAnalyzer(
            embedder = embedder,
            enrolled = if (enrollMode) null else store.load(),
            onState = { s -> state = s },
            onEnrolled = { e -> store.save(e) },
            onUnlocked = {},
        )
    }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }

    // Haptics, then fade to white and hand over once the badge animation is nearly done
    LaunchedEffect(state) {
        when (state) {
            ScanState.SUCCESS -> {
                vibrate(context, success = true)
                delay(1100)          // ring + check + hold
                whiteOut = true      // screen fades to white while the badge retracts
                delay(380)
                if (enrollMode) onEnrolled() else onUnlocked()
            }
            ScanState.FAIL -> vibrate(context, success = false)
            else -> {}
        }
    }

    // In unlock mode the camera runs invisibly, like a real phone
    LaunchedEffect(Unit) {
        if (!enrollMode) startCamera(context, lifecycleOwner, executor, analyzer, null)
    }

    val white by animateFloatAsState(if (whiteOut) 1f else 0f, tween(350), label = "white")
    val clock = remember { SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()) }
    val date = remember { SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(Date()) }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF14104F), Color(0xFF3B2FD0), Color(0xFFB45AE0))
                )
            )
    ) {
        FaceIdAnimation(
            state = state,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 12.dp)
        )

        Column(
            Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 130.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp)
            Text(clock, color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light)
        }

        if (enrollMode) {
            AndroidView(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(190.dp)
                    .clip(CircleShape),
                factory = { ctx ->
                    PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        startCamera(ctx, lifecycleOwner, executor, analyzer, this)
                    }
                }
            )
        }

        Text(
            text = when (state) {
                ScanState.SEARCHING -> when {
                    enrollMode -> "Position your face in the circle"
                    title != null -> "Unlock $title"
                    else -> "Look at your phone"
                }
                ScanState.SCANNING -> "Blink once to continue"
                ScanState.SUCCESS -> if (enrollMode) "Face saved" else "Unlocked"
                ScanState.FAIL -> "Face not recognised"
            },
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp)
        )

        // White fade at the end (the app screen appears underneath)
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.White.copy(alpha = white))
        )
    }
}

private fun startCamera(
    context: Context,
    owner: LifecycleOwner,
    executor: ExecutorService,
    analyzer: FaceAnalyzer,
    previewView: PreviewView?,
) {
    val future = ProcessCameraProvider.getInstance(context)
    future.addListener({
        val provider = future.get()
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { it.setAnalyzer(executor, analyzer) }
        provider.unbindAll()
        if (previewView != null) {
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        } else {
            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }
    }, ContextCompat.getMainExecutor(context))
}

private fun vibrate(context: Context, success: Boolean) {
    val vibrator = if (Build.VERSION.SDK_INT >= 31)
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    else @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    val effect = if (success)
        VibrationEffect.createWaveform(longArrayOf(0, 30, 60, 30), -1)
    else
        VibrationEffect.createWaveform(longArrayOf(0, 60, 40, 60, 40, 60), -1)
    vibrator.vibrate(effect)
}
