package com.example.facelock

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.concurrent.Executors

/**
 * Full-screen Face ID-style screen.
 * @param enrollMode true = save a new face, false = verify against the saved one.
 */
@Composable
fun FaceLockScreen(
    enrollMode: Boolean,
    onEnrolled: () -> Unit,
    onUnlocked: () -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val store = remember { FaceStore(context) }
    val embedder = remember { FaceEmbedder(context) }
    var state by remember { mutableStateOf(ScanState.SEARCHING) }
    val executor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) { onDispose { executor.shutdown() } }

    // Haptics + hand-off after the success animation finishes
    LaunchedEffect(state) {
        when (state) {
            ScanState.SUCCESS -> {
                vibrate(context, success = true)
                delay(900)
                if (enrollMode) onEnrolled() else onUnlocked()
            }
            ScanState.FAIL -> vibrate(context, success = false)
            else -> {}
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // Small circular camera preview in the middle, like a lock screen
        AndroidView(
            modifier = Modifier.align(Alignment.Center).size(190.dp).clip(CircleShape),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
                val providerFuture = ProcessCameraProvider.getInstance(ctx)
                providerFuture.addListener({
                    val provider = providerFuture.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also {
                            it.setAnalyzer(
                                executor,
                                FaceAnalyzer(
                                    embedder = embedder,
                                    enrolled = if (enrollMode) null else store.load(),
                                    onState = { s -> state = s },
                                    onEnrolled = { e -> store.save(e) },
                                    onUnlocked = {},
                                )
                            )
                        }
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            }
        )

        FaceIdAnimation(state = state, modifier = Modifier.align(Alignment.Center))

        Text(
            text = when (state) {
                ScanState.SEARCHING -> if (enrollMode) "Position your face in the frame" else "Face ID"
                ScanState.SCANNING -> "Blink once to continue"
                ScanState.SUCCESS -> if (enrollMode) "Face saved" else "Unlocked"
                ScanState.FAIL -> "Face not recognised"
            },
            color = Color.White,
            fontSize = 18.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp)
        )
    }
}

private fun vibrate(context: Context, success: Boolean) {
    val vibrator = if (Build.VERSION.SDK_INT >= 31)
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    else @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    val effect = if (success)
        VibrationEffect.createWaveform(longArrayOf(0, 30, 60, 30), -1)
    else
        VibrationEffect.createWaveform(longArrayOf(0, 60, 40, 60, 40, 60), -1)
    vibrator.vibrate(effect)
}
